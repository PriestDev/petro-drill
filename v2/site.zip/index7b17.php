<?xml version="1.0" encoding="utf-8"?>
<!-- generator="Joomla! - Open Source Content Management" -->
<feed xmlns="http://www.w3.org/2005/Atom"  xml:lang="en-gb">
	<title type="text">Petro-Drill Global Concepts | Oil &amp; Gas Exploration | World's Petroleum Training Alliance</title>
	<subtitle type="text">Petro-drill is a multinational energy servicing company with a global approach to a world leading state of the art oil and gas upstream exploration services and integrated project management. Our business is to provide quality service delivery to meet today’s complex energy challenges. </subtitle>
	<link rel="alternate" type="text/html" href="https://petrodrill-global.com"/>
	<id>https://petrodrill-global.com/v2/index.php</id>
	<updated>2026-02-17T13:12:24+00:00</updated>
	<generator uri="http://joomla.org">Joomla! - Open Source Content Management</generator>
	<link rel="self" type="application/atom+xml" href="https://petrodrill-global.com/v2/index.php?format=feed&amp;type=atom"/>
</feed>
