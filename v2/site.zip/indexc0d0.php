<?xml version="1.0" encoding="utf-8"?>
<!-- generator="Joomla! - Open Source Content Management" -->
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
	<channel>
		<title>Petro-Drill Global Concepts | Oil &amp; Gas Exploration | World's Petroleum Training Alliance</title>
		<description><![CDATA[Petro-drill is a multinational energy servicing company with a global approach to a world leading state of the art oil and gas upstream exploration services and integrated project management. Our business is to provide quality service delivery to meet today’s complex energy challenges. ]]></description>
		<link>https://petrodrill-global.com/v2/index.php/component/content/featured</link>
		<lastBuildDate>Tue, 17 Feb 2026 13:12:20 +0000</lastBuildDate>
		<generator>Joomla! - Open Source Content Management</generator>
		<atom:link rel="self" type="application/rss+xml" href="https://petrodrill-global.com/v2/index.php?format=feed&amp;type=rss"/>
		<language>en-gb</language>
	</channel>
</rss>
